# Matrix Chain Multiplication Optimizer

A responsive, standalone website based on the DSA-3 PowerPoint project.

## Run it
1. Extract `MatrixChain_Optimizer_Website.zip`.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Enter dimensions separated by commas/spaces and click **Calculate optimal order**.

No installation, server, database, or internet connection is required.

## Features
- Input validation and support for up to 500 matrices
- Bottom-up interval dynamic programming
- Optimal parenthesization and minimum scalar multiplication cost
- Naive left-to-right cost, savings percentage, and cost ratio
- Cost table and split table views
- Responsive dark dashboard and PPT example preset

## Example
Dimensions: `30, 35, 15, 5, 10, 20, 25`
Expected optimal cost: `15125`
Expected naive left-to-right cost: `40500`
